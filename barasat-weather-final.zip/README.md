# Barasat Weather

A simple production-ready Node.js weather dashboard fixed to Barasat, West Bengal, India.

## Providers

1. Open-Meteo — primary/free provider, no API key for non-commercial use.
2. WeatherAPI.com — optional API key, free plan currently gives 100K calls/month and 3-day forecast.
3. Tomorrow.io — optional API key, free plan currently gives hourly/daily forecast up to 5 days.

API keys are kept server-side in `.env`; they are never exposed to browser JavaScript.

## Run locally

```bash
npm install
cp .env.example .env
# Put your WeatherAPI and Tomorrow.io keys into .env
npm start
```

Open:

http://localhost:3000

## Production

Run behind Nginx/Cloudflare. The Node app listens on `127.0.0.1:3000` by default.

Example:

```bash
npm install
nano .env
npm start
```

For a persistent process, use PM2 or a systemd service.

## Important

The free Open-Meteo endpoint is for non-commercial use and has rate limits. The dashboard caches the three-provider response for 10 minutes to avoid unnecessary calls.

Weather forecasts are estimates and can change, especially short-term rainfall/thunderstorm forecasts.
